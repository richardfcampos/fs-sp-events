"use client"

import './globals.css'
import {ErrorBoundary} from "next/dist/client/components/error-boundary";
import Error from "@/app/error";

export default function HomeLayout({ children }: { children: React.ReactNode }) {

    return (
            <html>
                <body>
                    <ErrorBoundary errorComponent={Error}>
                        {children}
                    </ErrorBoundary>
                </body>
            </html>

    )
}
