export interface ResponseInterface {
    data: object;
    totalCount?: number;
    currentPage?: number;
    totalPages?: number;
}
