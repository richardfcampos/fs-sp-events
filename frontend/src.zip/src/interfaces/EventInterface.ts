export interface EventInterface {
    event_id: number;
    event_name: string;
    odds: number;
}
